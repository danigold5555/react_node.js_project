export enum ActionType {
  currentUserDetails,
    getAllVacations,
    userFollowedVacationsOrder,
    userFollowedVacationsArray,
    deleteVacation,
    addVacation,
    editVacation,
    isFollowedVacation,
}