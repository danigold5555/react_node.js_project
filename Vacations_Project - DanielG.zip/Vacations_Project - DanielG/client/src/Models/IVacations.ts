export default interface IVacations {
    id: number;
    destination: string;
    price: number;
    img: string;
    startDate: string;
    endDate: string;
    isFollowed: number;
    amountOfFollowers:number;
}