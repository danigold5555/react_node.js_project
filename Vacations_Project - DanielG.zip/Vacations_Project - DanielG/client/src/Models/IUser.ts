export default interface IUser {
    userId: number;
    userName: string;
    userType: string;
    isSiteLoggedin: number
}